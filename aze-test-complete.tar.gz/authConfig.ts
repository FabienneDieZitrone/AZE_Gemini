/**
 * Titel: MSAL Konfiguration für OAuth2
 * Version: Obsolet
 * Letzte Aktualisierung: 10.11.2024
 * Autor: MP-IT
 * Status: Veraltet
 * Datei: /authConfig.ts
 * Beschreibung: DIESE DATEI IST VERALTET. Die Authentifizierung wurde auf ein serverseitiges BFF-Modell (Backend for Frontend) umgestellt. Die gesamte MSAL-Logik wurde aus dem Frontend entfernt.
 */

// This file is no longer used and can be deleted.
