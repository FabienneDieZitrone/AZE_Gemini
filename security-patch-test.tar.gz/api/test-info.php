<?php echo json_encode(['environment' => 'test', 'deployment' => '20250805_163007', 'security_patch' => 'issue_74']); ?>
